

def salute():
	print("Helloooooo")


if __name__ == "__main__":
    print("Mira mi score privado")