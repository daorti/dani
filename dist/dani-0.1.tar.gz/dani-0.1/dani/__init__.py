# Inside of __init__.py
from franco.script_auxiliar import salute